/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Model.Agendamento;
import Model.Cliente;
import Model.Pessoa;
import Model.Servico;
import Model.Usuario;

/**
 *
 * @author xbit
 */
public class Main {
    
    
      public static void main(String[] args){
           
           String nome = "tiago";
           System.out.println(nome);
           
           Servico servico = new Servico(1, "lavagem", 25);
           
           System.out.println(servico.getDescricao());
           System.out.println(servico.getValor());
           
           
           Cliente cliente = new Cliente(1, "tiago", "rua teste", "1234555555");
           System.out.println(cliente.getNome());
           
           Usuario usuario = new Usuario(1, "funcionario", "senha");
           System.out.println(usuario.getNome());
           
           
           Agendamento agendamento = new Agendamento(1, cliente, servico, 25, "25/07/2022 08:15");
           System.out.println(agendamento.getCliente().getNome());
           
           
           
            
           
           
          
           
    
    
    }
    
    
}
