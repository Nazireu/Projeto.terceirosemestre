/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.Helper;

/**
 *
 * @author Magati
 */
public interface IHelper {
    
    public abstract Object obterModelo();
    
    public abstract void limparTela();
    
}
